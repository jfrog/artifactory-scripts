def id(x):
    return x
